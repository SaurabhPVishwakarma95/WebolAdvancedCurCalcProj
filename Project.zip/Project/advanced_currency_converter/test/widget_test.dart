// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/view/currencies_list.dart';
import 'package:advanced_currency_converter/view/currency_calculator.dart';
import 'package:advanced_currency_converter/view/settings.dart';
import 'package:advanced_currency_converter/view_model/state_notifier_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  await Hive.initFlutter();
  await Hive.openBox(Constants.baseCurrBoxName);

  testWidgets('Verify Widget Appearance Settings', (WidgetTester tester) async {

    final testSettingsProv = FutureProvider<String>((ref) async {
      return "Verify Test Settings";
    });

    // Build our app and trigger a frame.
    await tester.pumpWidget(
      ProviderScope(overrides: [
        settingsNotifierProvider.overrideWithProvider(testSettingsProv as StateNotifierProvider<StateNotifierSettings, List> Function(List argument)),
      ], child: const MaterialApp(home: Settings()))
      
    );

    // Verify that our counter starts at 0.
    expect(find.byType(CircleAvatar), findsOneWidget);

    // Tap the '+' icon and trigger a frame.
    await tester.pump();

    // Verify that our counter has incremented.
    expect(find.text('Verify Test Settings'), findsNothing);
  });

  testWidgets('Verify Widget Appearance Currency List', (WidgetTester tester) async {
    // Build our app and trigger a frame.

    final testCurrListProv = FutureProvider<String>((ref) async {
      return "Verify Test Currencies List";
    });

    // Build our app and trigger a frame.
    await tester.pumpWidget(
      ProviderScope(overrides: [
        settingsNotifierProvider.overrideWithProvider(testCurrListProv as StateNotifierProvider<StateNotifierSettings, List> Function(List argument)),
      ], child: const MaterialApp(home: CurrenciesList()))
      
    );

    // Verify that our counter starts at 0.
    expect(find.byType(CircleAvatar), findsOneWidget);

    // Tap the '+' icon and trigger a frame.
    await tester.pump();

    // Verify that our counter has incremented.
    expect(find.text('Verify Test Currencies List'), findsNothing);
  });

  testWidgets('Verify Widget Appearance Main', (WidgetTester tester) async {
    
    // Build our app and trigger a frame.
    await tester.pumpWidget(const CurrencyCalculator());

    // Tap the '+' icon and trigger a frame.
    await tester.tap(find.byIcon(Icons.arrow_drop_down));
    await tester.pump();

    // Verify that our counter has incremented.
    expect(find.text('USD'), findsOneWidget);
    // expect(find.text('1'), findsOneWidget);
  });  
}
