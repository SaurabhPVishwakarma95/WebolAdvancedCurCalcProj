import 'package:advanced_currency_converter/data/data_source_api_service.dart';

class DataRepository {
  getCurrCodeNameData() async {
    return await DataSourceApiService.relinquishCurrCodeNameData();
  }
}
