class Constants {
  static const String baseAPIUrl = "https://api.apilayer.com/exchangerates_data/";
  static const String mainScreenTitle = "Advance Currency App";
  static const String appTitleLbl = "Advance Currency App";
  static const String addCurrencyLbl = "Add Currency"; 
  static const String calculateTotalLbl = "Calculate Total"; 
  static const String totalLbl = "Total"; 
  static const String colonDelimiter = ":";
  static const String settingsLbl = "Settings"; 
  static const String currenciesListLbl = "Currencies List";
  static const String baseCurrencyLbl = "Base Currency";
  static const String dropdownDefaultLbl = "Select";
  static const String headerAPIKey = "apikey";
  static const String headerAPIValue = "6t9nb7OIiJTDIDyAVc2S4ienDnVkiBlo";
  static const int successStatus = 200;
}