import 'package:advanced_currency_converter/repository/data_repository.dart';
import 'package:flutter/services.dart';

mixin MixinCommon {
  getSymbolsList() async* {
    var listOfSymbols = [];
    var codeList = [];
    var nameList = [];
    var codeNameList = [];
    var dataRepository = DataRepository();
    listOfSymbols = await dataRepository.getCurrCodeNameData();
    for (MapEntry<String, dynamic> element in listOfSymbols) {
      codeList.add(element.key);
      nameList.add(element.value);
      codeNameList.add(
        {"code": element.key, "name": element.value},
      );
    }
    yield codeNameList;
  }

  lockScreenToPortrait() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);    
  }
}