import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/view/currencies_list.dart';
import 'package:advanced_currency_converter/view/currency_calculator.dart';
import 'package:advanced_currency_converter/view/settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/adapters.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox("openBoxBaseCurrency");

  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(      
      title: Constants.appTitleLbl,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const CurrencyCalculator(),      
    );
  }
}

