import 'package:advanced_currency_converter/common/constants.dart';
import 'package:dio/dio.dart';

class DataSourceApiService {
  static relinquishCurrCodeNameData() async {
    var codeAndName = [];
    var request = Dio(
      BaseOptions(
        baseUrl: Constants.baseAPIUrl,
        queryParameters: {
          Constants.headerAPIKey: Constants.headerAPIValue
        }
      )
    );

    var fetchRequest = await request.get("symbols");
    if(fetchRequest.statusCode == Constants.successStatus) {
      var response = fetchRequest.data;
      var symbols = response['symbols'];
      codeAndName = (symbols as Map<String, dynamic>).entries.toList();
    } else {
      codeAndName = [];
    }
    return codeAndName;
  }

  static relinquishExchangeRatesData() async {
    var request = Dio(
      BaseOptions(
        baseUrl: Constants.baseAPIUrl,
        headers: {
          Constants.headerAPIKey: Constants.headerAPIValue
        }
      )
    );

    var fetchRequest = await request.get("latest");
    if(fetchRequest.statusCode == Constants.successStatus) {
      var response = fetchRequest.data;
      return response;
    } else {
      return null;
    }
  }  
}
