class SelectCurrencyModel {
  List<dynamic>? selectedCurrRate = [];

  SelectCurrencyModel({
    required List<dynamic>? selectedCurrRate
  });

  SelectCurrencyModel copyWith({
    required List<dynamic>?  selectedCurrRate
  }) {
    return SelectCurrencyModel(selectedCurrRate: selectedCurrRate); 
  }
}