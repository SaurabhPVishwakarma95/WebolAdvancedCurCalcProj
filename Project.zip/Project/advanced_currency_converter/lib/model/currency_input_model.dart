class CurrencyInputModel {
  List<dynamic>? inputEntries = [];
  List<dynamic>? selectedCurrRate = [];
  double? total = 0.0;
  
  CurrencyInputModel({
    required this.inputEntries,
    this.selectedCurrRate,
    this.total
  });

  CurrencyInputModel copyWith({List<dynamic>? inputEntries, List<dynamic>? selectedCurrRate, double? total}) {
    return CurrencyInputModel(
      inputEntries: inputEntries ?? [],
      selectedCurrRate: selectedCurrRate,
      total: total ?? 0.0
    );
  }
}