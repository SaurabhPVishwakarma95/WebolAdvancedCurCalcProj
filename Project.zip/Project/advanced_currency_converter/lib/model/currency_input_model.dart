class CurrencyInputModel {
  List<dynamic> inputEntries = [];
  double? total = 0.0;
  
  CurrencyInputModel({
    required this.inputEntries,
    this.total
  });

  CurrencyInputModel copyWith({List<dynamic>? inputEntries, double? total}) {
    return CurrencyInputModel(
      inputEntries: inputEntries! ?? this.inputEntries,
      total: total! ?? this.total
    );
  }
}