import 'package:advanced_currency_converter/model/select_currency_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class StateNotifierSelectCurr extends StateNotifier<SelectCurrencyModel> {
  StateNotifierSelectCurr(): super(SelectCurrencyModel(selectedCurrRate: [""]));

  updateSelectedCurr(var index, var selectedCurr) {
    if(index < 0 || index >= state.selectedCurrRate!.length) {
      return;
    }
    var listOfCurrency = [...state.selectedCurrRate!];
    listOfCurrency[index] = selectedCurr;
    state.selectedCurrRate = listOfCurrency;
  }
}

final stateNotifierSelCurrProvider = StateNotifierProvider<StateNotifierSelectCurr, SelectCurrencyModel>((ref) {
  return StateNotifierSelectCurr();
});