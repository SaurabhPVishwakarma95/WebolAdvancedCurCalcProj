import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/model/currency_input_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

class StateNotifierCalcMain extends StateNotifier<CurrencyInputModel> {
  StateNotifierCalcMain():super(CurrencyInputModel(inputEntries: [""]));
  
  Box dbBox = Hive.box(Constants.baseCurrBoxName);
  var selectedBaseRate;

  void collectInputEntries() {
    var valuesForAddition = [...state.inputEntries!, ""];
    state = state.copyWith(inputEntries: valuesForAddition);
  }

  void updateTotal(var index, var value) {
    if(index < 0 || index >= state.inputEntries!.length) {
      return;
    }
    var valuesForUpdation = [...state.inputEntries!];
    valuesForUpdation[index] = value;
    state.inputEntries = valuesForUpdation;
  }

  computeTotal() {
    selectedBaseRate = double.tryParse(dbBox.get(Constants.keySettingBaseRate) ?? 0) ?? 0;
    var summedTotal = state.inputEntries!.map((input) => double.tryParse(input) ?? 0).reduce((first, second) => first + second);
    state = state.copyWith(total: summedTotal * selectedBaseRate);
  }

  updateSelectedCurr(var index, var selectedCurr) {
    if(state.selectedCurrRate == null) {
      state.selectedCurrRate = [...state.selectedCurrRate!];
    }   
    if(index < 0 || index >= state.selectedCurrRate!.length) {
      return;
    }
    var listOfCurrency = [...state.selectedCurrRate!, selectedCurr];
    listOfCurrency[index] = selectedCurr;
    state.selectedCurrRate = listOfCurrency.toSet().toList();
    return listOfCurrency.toSet().toList();
  }
}

final stateNotifierCalcMainProvider = StateNotifierProvider<StateNotifierCalcMain, CurrencyInputModel>((ref) {
  return StateNotifierCalcMain();
});
