import 'package:advanced_currency_converter/model/currency_input_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class StateNotifierCalcMain extends StateNotifier<CurrencyInputModel> {
  StateNotifierCalcMain():super(CurrencyInputModel(inputEntries: [""]));

  void collectInputEntries() {
    var valuesForAddition = [...state.inputEntries, 0.0];
    state = state.copyWith(inputEntries: valuesForAddition);
  }

  void updateTotal(var index, var value) {
    var valuesForUpdation = [value];
    valuesForUpdation[index] = value;
    state = state.copyWith(inputEntries: valuesForUpdation);
    print("Inputs: ${state.inputEntries}");

  }

  void computeTotal() {
    var summedTotal = state.inputEntries.map((input) => double.tryParse(input) ?? 0).reduce((first, second) => first + second);
    state = state.copyWith(total: summedTotal);
  }
}

final StateNotifierCalcMainProvider = StateNotifierProvider<StateNotifierCalcMain, CurrencyInputModel>((ref) {
  return StateNotifierCalcMain();
});
