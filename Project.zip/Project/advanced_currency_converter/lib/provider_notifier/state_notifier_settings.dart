import 'package:flutter_riverpod/flutter_riverpod.dart';

class StateNotifierSettings extends StateNotifier<List<dynamic>> {
  StateNotifierSettings(super.listOfData);
  
  updateSwitchStatus(String code) {
    state = state.map((codeAndName) {
      try {
        if(codeAndName!["code"] == code) {
          return {...codeAndName, "status": !(codeAndName["status"] as bool)};
        } else {
          return {...codeAndName, "status": false};
        }
      } catch(exception) {
        print(exception);
      }
    }).toList();
  }
}

// Notifier Provider
final settingsNotifierProvider = StateNotifierProvider.family<StateNotifierSettings, List<dynamic>, List<dynamic>>((ref, data) {
  return StateNotifierSettings(data);
});

