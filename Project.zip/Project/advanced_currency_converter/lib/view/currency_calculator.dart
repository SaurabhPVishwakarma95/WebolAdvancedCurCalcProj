import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/common/mixin_common.dart';
import 'package:advanced_currency_converter/view_model/state_notifier_calc_main.dart';
import 'package:advanced_currency_converter/view/currencies_list.dart';
import 'package:advanced_currency_converter/view/settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

class CurrencyCalculator extends ConsumerStatefulWidget {
  const CurrencyCalculator({super.key});

  @override
  ConsumerState<CurrencyCalculator> createState() => _CurrencyCalculatorState();
}

class _CurrencyCalculatorState extends ConsumerState<CurrencyCalculator> with MixinCommon {

  late Box dbBox;
  List<Map<String, dynamic>> mExchangeRates = [];
  List<Map<String, dynamic>> refinedExRatesList = [];
  List<Map<String, dynamic>> utilizeExRatesList = [];
  var rateSelected;
  
  @override
  void initState() {    
    super.initState();
    lockScreenToPortrait();
    dbBox = Hive.box(Constants.baseCurrBoxName);
    mExchangeRates = Constants.exchangeRates.entries.where((listOfCurr) => listOfCurr.key == "rates").map((listOfCurr) => {listOfCurr.key: listOfCurr.value}).toList();
    for(var element in mExchangeRates) {
      refinedExRatesList.add(element["rates"]);
    }
    refinedExRatesList.asMap()[0]!.forEach((key,value) {
      utilizeExRatesList.add({"code": key, "rate": value});
    });
  }

  @override
  void didChangeDependencies() {    
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    var currencyCalcProvider = ref.watch(stateNotifierCalcMainProvider);
    var currCalcViewModel = ref.read(stateNotifierCalcMainProvider.notifier);

    selectCurrency(int indexFromField) async {
      return showModalBottomSheet(
        context: context, builder: (_) {
            return SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height/(1.3),
            child: ListView.builder(
              itemCount: utilizeExRatesList.length,
              itemBuilder: (item, index) {
                Map<String, dynamic> currRatesKeyVal = utilizeExRatesList[index];
                return ListTile(
                  selectedTileColor: Colors.lightGreen,
                  title: Text(currRatesKeyVal["code"].toString()),
                  subtitle: Text(currRatesKeyVal["rate"].toString()),
                  trailing: Text(currencyCalcProvider.selectedCurrRate != null ? currencyCalcProvider.selectedCurrRate![0].toString() : ""),
                  onTap: () {
                    Navigator.pop(context);
                    currCalcViewModel.updateSelectedCurr(indexFromField, currRatesKeyVal["rate"]);
                  },
                );
              })
            );
      });
    }

    var widgetForInput = currencyCalcProvider.inputEntries!.asMap().entries.map((input) {
      var inputIndex = input.key;
      return Row(
        children: [
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: Constants.enterMsg
                ),
                keyboardType: TextInputType.number,
                maxLength: 10,                                
                onChanged: (value) {
                  currCalcViewModel.updateTotal(inputIndex, value);
                },
              ),
            ),
          ),
      
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Text(currencyCalcProvider.selectedCurrRate != null ? currencyCalcProvider.selectedCurrRate.toString() : "Select"),
                  IconButton(onPressed: () {
                    rateSelected = selectCurrency(inputIndex);
                  }, icon: const Icon(Icons.arrow_drop_down)),
                ],
              )
            ),
          ),      
        ],
      );
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(Constants.mainScreenTitle),        
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        onTap: (value) {
          switch (value) {
            case 0:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const Settings()));
              break;
            case 1:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const CurrenciesList()));
              break;
            default:
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: Constants.settingsLbl),
          BottomNavigationBarItem(icon: Icon(Icons.currency_exchange), label: Constants.currenciesListLbl),
        ]
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      currCalcViewModel.collectInputEntries();
                    },
                    child: Container(
                      margin: const EdgeInsets.only(right: 2.0),
                      width: MediaQuery.of(context).size.width/2,
                      height: 70,
                      color: Colors.teal[400],
                      child: const Center(child: Text(Constants.addCurrencyLbl, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),)),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      currCalcViewModel.computeTotal();                      
                    },
                    child: Container(
                      margin: const EdgeInsets.only(left: 2.0),
                      width: MediaQuery.of(context).size.width/2,
                      height: 70,
                      color: Colors.teal[400],
                      child: const Center(child: Text(Constants.calculateTotalLbl, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),)),
                    ),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text("${Constants.totalLbl}: ${(currencyCalcProvider.total != null ? (currencyCalcProvider.total!) : (0.0).toString())}", style: const TextStyle(fontWeight: FontWeight.bold),),
                )
              ],
            ),
            Column(
              children: widgetForInput,
            )
          ],
        ),
      ),
    );
  }
}