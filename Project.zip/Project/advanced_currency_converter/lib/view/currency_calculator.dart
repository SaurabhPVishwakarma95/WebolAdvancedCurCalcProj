import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/common/mixin_common.dart';
import 'package:advanced_currency_converter/view_model/state_notifier_calc_main.dart';
import 'package:advanced_currency_converter/view/currencies_list.dart';
import 'package:advanced_currency_converter/view/settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class CurrencyCalculator extends ConsumerStatefulWidget {
  const CurrencyCalculator({super.key});

  @override
  ConsumerState<CurrencyCalculator> createState() => _CurrencyCalculatorState();
}

class _CurrencyCalculatorState extends ConsumerState<CurrencyCalculator> with MixinCommon {

  @override
  void initState() {    
    super.initState();
    lockScreenToPortrait();    
  }

  @override
  Widget build(BuildContext context) {

    final currencyCalcProvider = ref.watch(StateNotifierCalcMainProvider);
    final currCalcViewModel = ref.read(StateNotifierCalcMainProvider.notifier);

    var widgetForInput = currencyCalcProvider.inputEntries.asMap().entries.map((input) {
      var inputIndex = input.key;
      var inputValue = input.value;
      
      return Row(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  currCalcViewModel.updateTotal(inputIndex, inputValue);
                },
              ),
            ),
          ),
      
        ],
      );
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(Constants.mainScreenTitle),        
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        onTap: (value) {
          switch (value) {
            case 0:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const Settings()));
              break;
            case 1:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const CurrenciesList()));
              break;
            default:
          }
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: Constants.settingsLbl),
          BottomNavigationBarItem(icon: Icon(Icons.currency_exchange), label: Constants.currenciesListLbl),
        ]
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      currCalcViewModel.collectInputEntries();
                    },
                    child: Container(
                      margin: const EdgeInsets.only(right: 2.0),
                      width: MediaQuery.of(context).size.width/2,
                      height: 70,
                      color: Colors.teal[400],
                      child: const Center(child: Text(Constants.addCurrencyLbl, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),)),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      currCalcViewModel.computeTotal();
                    },
                    child: Container(
                      margin: const EdgeInsets.only(left: 2.0),
                      width: MediaQuery.of(context).size.width/2,
                      height: 70,
                      color: Colors.teal[400],
                      child: const Center(child: Text(Constants.calculateTotalLbl, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),)),
                    ),
                  ),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text("${Constants.totalLbl}: ${currencyCalcProvider.total}", style: TextStyle(fontWeight: FontWeight.bold),),
                )
              ],
            ),
            Column(
              children: widgetForInput,
            )
          ],
        ),
      ),
    );
  }
}