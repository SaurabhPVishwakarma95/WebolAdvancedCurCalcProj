import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/common/mixin_common.dart';
import 'package:advanced_currency_converter/repository/data_repository.dart';
import 'package:flutter/material.dart';

class CurrenciesList extends StatefulWidget {
  const CurrenciesList({super.key});

  @override
  State<CurrenciesList> createState() => _CurrenciesListState();
}

class _CurrenciesListState extends State<CurrenciesList> with MixinCommon {
  var dataRepository = DataRepository();
  var listOfSymbols = [];
  var codeList = [];
  var nameList = [];
  var codeNameList = [];

  @override
  void initState() {    
    super.initState();
    getSymbolsList();
  }

  @override
  getSymbolsList() async* {
    listOfSymbols = await dataRepository.getCurrCodeNameData();
    for (MapEntry<String, dynamic> element in listOfSymbols) {
      codeList.add(element.key);
      nameList.add(element.value);
      codeNameList.add(
        {"code": element.key, "name": element.value},
      );
    }
    yield codeNameList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(Constants.currenciesListLbl),      
      ),
      body: StreamBuilder(stream: getSymbolsList(), builder: (context, asyncSnapshot) {
        if(asyncSnapshot.connectionState == ConnectionState.none) {
          return const Center(child: Text(Constants.noData),);
        } else if(asyncSnapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(),);
        }      
        return ListView.builder(
          itemCount: codeNameList.length,
          itemBuilder: (item, index) {
            return ListTile(
              leading: CircleAvatar(
                child: Text((index+1).toString()),
              ),
              title: Text(codeNameList[index]["code"].toString()),
              subtitle: Text(codeNameList[index]["name"].toString()),
            );
          },
        );
      }),
    );
  }
}