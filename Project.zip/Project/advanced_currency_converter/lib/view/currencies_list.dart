import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/repository/data_repository.dart';
import 'package:flutter/material.dart';

class CurrenciesList extends StatefulWidget {
  const CurrenciesList({super.key});

  @override
  State<CurrenciesList> createState() => _CurrenciesListState();
}

class _CurrenciesListState extends State<CurrenciesList> {
  var dataRepository = DataRepository();
  var listOfSymbols = [];
  var codeList = [];
  var nameList = [];
  var codeNameList = [];

  @override
  void initState() {    
    super.initState();
    getSymbolsList();
  }

  getSymbolsList() async* {
    listOfSymbols = await dataRepository.getCurrCodeNameData();
    for (MapEntry<String, dynamic> element in listOfSymbols) {
      codeList.add(element.key);
      nameList.add(element.value);
      codeNameList.add(
        {"code": element.key, "name": element.value},
      );
    }
    yield codeNameList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(Constants.currenciesListLbl),      
      ),
      body: StreamBuilder(stream: getSymbolsList(), builder: (asyncSnapshot, context) {
        return ListView.builder(
          itemCount: codeNameList.length,
          itemBuilder: (item, index) {
            return ListTile(
              title: Text(codeNameList[index]["code"].toString()),
              subtitle: Text(codeNameList[index]["name"].toString()),
            );
          },
        );
      }),
    );
  }
}