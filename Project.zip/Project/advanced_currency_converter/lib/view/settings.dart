import 'package:advanced_currency_converter/common/constants.dart';
import 'package:advanced_currency_converter/common/mixin_common.dart';
import 'package:advanced_currency_converter/provider_notifier/state_notifier_settings.dart';
import 'package:advanced_currency_converter/repository/data_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Settings extends ConsumerStatefulWidget {
  const Settings({super.key});

  @override
  ConsumerState<Settings> createState() => _SettingsState();
}

class _SettingsState extends ConsumerState<Settings> with MixinCommon {
  var appBarTitle = "${Constants.settingsLbl} Base Currency";
  var dataRepository = DataRepository();
  var exchangeRates, mDefaultBaseCurrency;
  var listOfSymbols = [];
  var codeList = [];
  var nameList = [];
  var codeNameList = [];
  bool switchStatus = false;
  var keyCust = GlobalKey();
  late Box boxBaseCurrency;

  @override
  void initState() {    
    super.initState();
    codeNameList = Constants.codeNameList;
    exchangeRates = Constants.exchangeRates;
    initSharedPref();
    codeNameList.forEach((element) {
      if(element["code"] == boxBaseCurrency.get(Constants.keySelectedCurrency).toString()) {
        element["status"] = true;
      } else {
        element["status"] = false;
      }
    });
  }

  initSharedPref() async {
    boxBaseCurrency = Hive.box("openBoxBaseCurrency");    
  }

  @override
  getSymbolsList() async* {
    // Note: Uncomment for API if hits in Free Subscription remaining.
    // exchangeRatesData();
    // listOfSymbols = await dataRepository.getCurrCodeNameData();
    // for (MapEntry<String, dynamic> element in listOfSymbols) {
    //   codeList.add(element.key);
    //   nameList.add(element.value);
    //   codeNameList.add(
    //     {"code": element.key, "name": element.value, "status" : element.key.toString() == mDefaultBaseCurrency ? true : false},
    //   );
    // }
    yield codeNameList;
  }

  exchangeRatesData() async {    
    // Note: Uncomment for API if hits in Free Subscription remaining.
    // exchangeRates = await dataRepository.getExchangeRatesData();
    // mDefaultBaseCurrency = exchangeRates["base"] ?? Constants.defaultCurrency;      
    // var baseRate = exchangeRates["rates"][mDefaultBaseCurrency];
    // print(baseRate);
  }

  @override
  Widget build(BuildContext context) {
    int listLength = codeNameList.length;
    final settingsStatus = ref.watch(settingsNotifierProvider(codeNameList));

    return Scaffold(
      appBar: AppBar(
        title: Text(appBarTitle),
      ),
      body: StreamBuilder(stream: getSymbolsList(), builder: (context, asyncSnapshot) {
        if(asyncSnapshot.connectionState == ConnectionState.none) {
          return const Center(child: Text(Constants.noData),);
        } else if(asyncSnapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(),);
        }
        return ListView.builder(
          itemCount: codeNameList.length > listLength ? listLength : codeNameList.length,
          itemBuilder: (item, index) {
            return index > codeNameList.length ? Container() : ListTile(
              leading: CircleAvatar(
                child: Text((index+1).toString()),
              ),
              trailing: SizedBox(
                width: 70,
                height: 40,
                child: Switch(value: settingsStatus[index > codeNameList.length ? codeNameList.length-1 : index]["status"] ?? false, onChanged: (value) {
                  var baseCurrCode = codeNameList[index > codeNameList.length ? codeNameList.length-1 : index]["code"];
                  String preferredBaseCurrRate = exchangeRates["rates"][baseCurrCode].toString();
                  boxBaseCurrency.put(Constants.keySettingBaseRate, preferredBaseCurrRate.toString());
                  boxBaseCurrency.put(Constants.keySelectedCurrency, baseCurrCode.toString());
                  ref.read(settingsNotifierProvider(codeNameList).notifier).updateSwitchStatus(codeNameList[index > codeNameList.length ? codeNameList.length-1 : index]["code"]);
                }),
              ),
              title: Row(
                children: [
                  Text(settingsStatus[index > codeNameList.length ? codeNameList.length-1 : index]["code"].toString()),
                  Text(boxBaseCurrency.get(Constants.keySettingBaseRate).toString()),
                  Text(boxBaseCurrency.get(Constants.keySelectedCurrency).toString())
                ],
              ),
              subtitle: Text(settingsStatus[index > codeNameList.length ? codeNameList.length-1 : index]["name"].toString()),
            );
          },
        );
      }),
    );
  }
}