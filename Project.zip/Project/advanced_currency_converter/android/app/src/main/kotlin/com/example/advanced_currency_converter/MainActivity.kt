package com.example.advanced_currency_converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
